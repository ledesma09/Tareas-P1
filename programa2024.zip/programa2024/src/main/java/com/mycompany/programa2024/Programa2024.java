/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.programa2024;



/**
 *
 * @author Tenza
 */
public class Programa2024 {

    public static void main(String[] args) {
         LoginVotantes objetoMenu = new LoginVotantes();
         objetoMenu.setVisible(true);
         objetoMenu.setLocationRelativeTo(null);
}
    
    }
